package Joops;

public class Parasecond {
public Parasecond(int a,int b) {
	System.out.println(a+b);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Parasecond p = new Parasecond(6,2);
	}

}
