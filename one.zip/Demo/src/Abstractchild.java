
public class Abstractchild extends Exampleabstract{
  public void walk() {
	  System.out.println("walking");
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Abstractchild obj = new Abstractchild();
obj.run();
obj.walk();
	}

}
