
abstract class Exampleabstract {
	
	public void run() {
		System.out.println("running");
	}
	public abstract void walk();

}
