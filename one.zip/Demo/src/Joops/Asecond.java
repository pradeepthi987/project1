package Joops;

public class Asecond extends Heelo {

	public void run() {
		System.out.println("running");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Asecond obj = new Asecond();
		obj.hello();
		obj.run();

	}

}
