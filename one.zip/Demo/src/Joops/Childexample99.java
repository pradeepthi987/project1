package Joops;

public class Childexample99 extends Example99{

	public void meth2() {
		
		System.out.println("hello");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Childexample99 c= new Childexample99();
		c.meth1();
		c.meth2();
	}

}
