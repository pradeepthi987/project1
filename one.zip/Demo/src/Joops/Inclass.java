package Joops;

public class Inclass implements Example {

	public void baby() {
		System.out.println("baby is crying");
	}
	public void girl() {
		System.out.println("girl is walking");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Inclass obj = new Inclass();
obj.baby();
obj.girl();
	}

}
