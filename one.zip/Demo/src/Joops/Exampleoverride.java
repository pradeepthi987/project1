package Joops;

public class Exampleoverride {

	public void start() {
		System.out.println("car starts");
	}
	public void stop() {
		System.out.println("car stops");
	}
}
