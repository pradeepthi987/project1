package Joops;

public class Secondhello extends Exampleinherit{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Secondhello obj = new Secondhello();
    obj.hi();
    obj.hello();
	}

}

