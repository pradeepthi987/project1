package Joops;

public abstract class Example99 {
	public void meth1() {
		System.out.println("hi");
	}
  public abstract void meth2();
}
