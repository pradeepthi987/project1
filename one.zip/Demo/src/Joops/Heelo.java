package Joops;

abstract class Heelo {

	public void hello() {
		System.out.println("say hello");
	}
   public  abstract void run();
}
