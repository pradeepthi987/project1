package demoprograms;

import java.util.Arrays;

public class Second {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] = {1,2,3,4};
		Arrays.sort(a);
      System.out.println(a[0]);
     
	}

}
