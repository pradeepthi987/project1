
public class Test {
  static    {
	  System.out.println("hello");
  }
}
