
public class Staticexample {
	String a = "xyz";
 public  void meth() {
	 System.out.println("reddy");
 }
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
System.out.println("deepthi");
	}

}
