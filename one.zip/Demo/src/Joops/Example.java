package Joops;

public interface Example {
   abstract public void baby();
   abstract public void girl();
}
