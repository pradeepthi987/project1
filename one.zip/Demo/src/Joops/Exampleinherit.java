package Joops;

public class Exampleinherit {

	public void hi() {
		System.out.println("say hi");
	}
   public void hello() {
	   System.out.println("say hello");
   }
}
